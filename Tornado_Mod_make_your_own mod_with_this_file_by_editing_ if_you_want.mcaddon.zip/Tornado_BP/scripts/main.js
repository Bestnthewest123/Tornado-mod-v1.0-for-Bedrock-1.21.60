// ============================================================
//  Realistic Tornado + Thunderbolt 1000T siren  (Minecraft Bedrock 1.21.60)
//  Script-driven tornado: funnel particles, suction, debris, damage,
//  block destruction, lightning and storm weather.
// ============================================================
import { world, system } from "@minecraft/server";

// ===================== CONFIG (edit me) =====================
const CFG = {
  ITEM_ID: "tornado:summoner",          // staff that spawns tornadoes
  SIREN_ID: "tornado:thunderbolt_1000t", // the Thunderbolt 1000T siren block
  SIREN_VOLUME: 23,       // >1 extends how far away the siren can be heard (~16 blocks per 1.0)
  SIREN_LEN_TICKS: 560,   // length of the siren sound file in ticks (28 s)
  SIREN_AUTO_RANGE: 300,  // sirens start by themselves if a tornado is this close (blocks)
  LIFETIME_TICKS: 1000,   // tornado lifespan in ticks (20 ticks = 1 second)
  MAX_TORNADOES: 3,       // max active at once (performance)
  MAX_RANGE: 80,          // how far the staff can aim (blocks)
  DESTROY_BLOCKS: true,   // tornado rips up blocks (set false for a harmless one)
  LIGHTNING: true,        // lightning strikes around the tornado
  FORCE_STORM: true,      // switches overworld weather to thunder when one spawns
  DEFAULT_EF: 1,          // default strength of the staff (0-5)
  USE_COOLDOWN: 40        // ticks between staff uses
};

// Enhanced Fujita scale presets
const EF = [
  { name: "EF0", baseR: 1.5, topR: 4,  height: 18, pull: 0.45, damage: 0,  speed: 0.07, blocks: 1,  bolt: 260 },
  { name: "EF1", baseR: 2.5, topR: 6,  height: 26, pull: 0.60, damage: 1,  speed: 0.08, blocks: 2,  bolt: 200 },
  { name: "EF2", baseR: 3.5, topR: 8,  height: 36, pull: 0.80, damage: 2,  speed: 0.09, blocks: 3,  bolt: 160 },
  { name: "EF3", baseR: 4.5, topR: 11, height: 48, pull: 1.00, damage: 4,  speed: 0.10, blocks: 5,  bolt: 120 },
  { name: "EF4", baseR: 6.0, topR: 14, height: 60, pull: 1.25, damage: 6,  speed: 0.12, blocks: 7,  bolt: 90 },
  { name: "EF5", baseR: 7.5, topR: 18, height: 72, pull: 1.50, damage: 10, speed: 0.14, blocks: 10, bolt: 60 }
];

// ===================== BLOCK RULES =====================
const NEVER = ["bedrock", "obsidian", "barrier", "command_block", "structure", "portal", "spawner",
  "water", "lava", "air", "netherite", "ancient_debris", "reinforced", "end_", "beacon", "chest",
  "barrel", "shulker", "furnace", "anvil", "enchanting", "respawn", "ore", "sculk"];
const WEAK = ["leaves", "grass", "flower", "fern", "sapling", "vine", "glass", "wool", "carpet", "torch",
  "sign", "door", "fence", "planks", "pane", "wheat", "carrots", "potatoes", "beetroot", "bamboo",
  "cactus", "sugar_cane", "pumpkin", "melon", "hay_block", "scaffolding", "banner", "_bed", "trapdoor",
  "ladder", "bookshelf", "snow_layer", "lantern", "mushroom", "azalea", "dripleaf", "rose", "tulip",
  "dandelion", "poppy", "lily", "berry", "kelp", "coral"];
const WOOD = ["log", "wood", "stripped", "slab", "stairs", "wall", "stem"];
const EARTH = ["dirt", "sand", "gravel", "grass_block", "terracotta", "concrete", "bricks", "cobblestone",
  "mud", "clay", "snow", "podzol", "mycelium"];
const ROCK = ["stone", "andesite", "diorite", "granite", "deepslate", "tuff", "calcite"];

function canBreak(rawId, level) {
  const id = rawId.replace("minecraft:", "");
  if (NEVER.some((n) => id.includes(n))) return false;
  if (WEAK.some((n) => id.includes(n))) return true;
  if (level >= 3 && WOOD.some((n) => id.includes(n))) return true;
  if (level >= 4 && EARTH.some((n) => id.includes(n))) return true;
  if (level >= 5 && ROCK.some((n) => id.includes(n))) return true;
  return false;
}

const IGNORE = new Set(["minecraft:lightning_bolt", "minecraft:armor_stand", "minecraft:painting"]);

// ===================== STATE =====================
const tornadoes = [];
const lastUse = new Map();

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

function getLevel(player) {
  try {
    const v = player.getDynamicProperty("tornado:ef");
    if (typeof v === "number") return clamp(v, 0, 5);
  } catch {}
  return CFG.DEFAULT_EF;
}

function groundY(dim, x, z, fallback) {
  try {
    const top = dim.getTopmostBlock({ x: Math.floor(x), z: Math.floor(z) });
    if (top) return top.y + 1;
  } catch {}
  return fallback;
}

// ===================== SPAWNING =====================
function spawnTornado(dim, x, z, level, life = CFG.LIFETIME_TICKS) {
  if (tornadoes.length >= CFG.MAX_TORNADOES) return false;
  const y = groundY(dim, x, z, 64);
  tornadoes.push({
    dim: dim.id, x, y, z, level: clamp(level, 0, 5), age: 0, life,
    heading: Math.random() * Math.PI * 2, errors: 0
  });

  if (CFG.FORCE_STORM && dim.id === "minecraft:overworld") {
    try { dim.runCommand("weather thunder"); } catch {}
  }
  try { dim.playSound("ambient.weather.thunder", { x, y, z }, { volume: 6, pitch: 0.7 }); } catch {}
  world.sendMessage(`§e⚡ §fA §c${EF[clamp(level, 0, 5)].name}§f there has encountered to be a tornado touch down!`);
  return true;
}

function strikeLightning(dim, x, z, fallbackY) {
  const y = groundY(dim, x, z, fallbackY);
  try { dim.spawnEntity("minecraft:lightning_bolt", { x, y, z }); } catch {}
}

// ===================== SIMULATION =====================
function stepTornado(t) {
  const dim = world.getDimension(t.dim);
  const L = EF[t.level];
  t.age++;
  if (t.age >= t.life) {
    world.sendMessage("§7The tornado dissipates...");
    return false;
  }

  // Grow in, shrink out
  const s = clamp(Math.min(t.age / 100, (t.life - t.age) / 100), 0.15, 1);
  const rBase = L.baseR * s, rTop = L.topR * s, H = L.height * s;

  // Wander across the terrain
  t.heading += (Math.random() - 0.5) * 0.05;
  t.x += Math.cos(t.heading) * L.speed;
  t.z += Math.sin(t.heading) * L.speed;
  if (t.age % 5 === 0) {
    const gy = groundY(dim, t.x, t.z, t.y);
    t.y += (gy - t.y) * 0.5;
  }

  const rAt = (h) => rBase + (rTop - rBase) * Math.pow(clamp(h / H, 0, 1), 1.5);

  // ---- Funnel particles ----
  const step = Math.max(2, Math.round(H / 20));
  for (let h = 0; h <= H; h += step) {
    const r = rAt(h);
    const ang = t.age * 0.35 + h * 0.3;
    for (let k = 0; k < 3; k++) {
      const a = ang + (k * Math.PI * 2) / 3;
      const pos = { x: t.x + Math.cos(a) * r, y: t.y + h, z: t.z + Math.sin(a) * r };
      dim.spawnParticle(k === 0 ? "minecraft:basic_dust_particle" : "minecraft:dust_particle", pos);
    }
  }
  // Ground dust ring
  for (let i = 0; i < 4; i++) {
    const a = Math.random() * Math.PI * 2, r = rBase * (1 + Math.random() * 0.8);
    dim.spawnParticle("minecraft:campfire_smoke_particle", { x: t.x + Math.cos(a) * r, y: t.y + 0.3, z: t.z + Math.sin(a) * r });
  }
  // Storm cloud at the top + sparks
  if (t.age % 2 === 0) {
    for (let i = 0; i < 4; i++) {
      const a = Math.random() * Math.PI * 2, r = rTop * (0.8 + Math.random() * 0.8);
      dim.spawnParticle("minecraft:basic_smoke_particle", { x: t.x + Math.cos(a) * r, y: t.y + H + 1, z: t.z + Math.sin(a) * r });
    }
    if (CFG.LIGHTNING && Math.random() < 0.3) {
      try {
        const a = Math.random() * Math.PI * 2, r = rTop * Math.random();
        dim.spawnParticle("minecraft:electric_spark_particle", { x: t.x + Math.cos(a) * r, y: t.y + H * Math.random(), z: t.z + Math.sin(a) * r });
      } catch {}
    }
  }

  // ---- Sound ----
  if (t.age % 20 === 0) {
    try { dim.playSound("mob.enderdragon.flap", { x: t.x, y: t.y + 2, z: t.z }, { volume: 3 + L.pull * 2, pitch: 0.5 }); } catch {}
  }

  // ---- Suction, lift, damage ----
  const cy = t.y + H / 2;
  const maxReach = Math.max(rTop * 2.2 + 4, H / 2) + 6;
  const ents = dim.getEntities({ location: { x: t.x, y: cy, z: t.z }, maxDistance: maxReach });
  for (const e of ents) {
    if (IGNORE.has(e.typeId)) continue;
    const isPlayer = e.typeId === "minecraft:player";
    if (isPlayer) {
      try {
        const gm = e.getGameMode();
        if (gm === "creative" || gm === "spectator") continue;
      } catch {}
    }
    const p = e.location;
    if (p.y < t.y - 4 || p.y > t.y + H + 12) continue;
    const dx = t.x - p.x, dz = t.z - p.z;
    const d = Math.hypot(dx, dz);
    const rHere = rAt(clamp(p.y - t.y, 0, H));
    const reach = rHere * 2.2 + 4;
    if (d > reach || d < 0.001) continue;

    const f = Math.max(0, 1 - d / reach) * L.pull * s;
    const inx = dx / d, inz = dz / d;
    const tx = -inz, tz = inx;                  // swirl direction
    const rising = p.y < t.y + H;
    let ix = (inx * 0.5 + tx * 0.9) * f * 0.14;
    let iz = (inz * 0.5 + tz * 0.9) * f * 0.14;
    let iy = (rising ? 1 : -0.4) * f * 0.15;
    if (!rising) { ix -= inx * f * 0.1; iz -= inz * f * 0.1; } // fling debris outward at the top

    if (isPlayer) {
      const hs = Math.hypot(ix, iz);
      if (hs > 0) {
        try { e.applyKnockback(ix / hs, iz / hs, hs * 2.5, iy * 2.5); }
        catch { try { e.applyKnockback({ x: ix * 2.5, z: iz * 2.5 }, iy * 2.5); } catch {} }
      }
    } else {
      try { e.applyImpulse({ x: ix, y: iy, z: iz }); } catch {}
    }

    if (t.age % 10 === 0 && L.damage > 0 && d < rHere * 1.1 && p.y >= t.y && p.y <= t.y + H) {
      try { e.applyDamage(L.damage * Math.min(1, s * 1.5), { cause: "contact" }); } catch {}
    }
  }

  // ---- Block destruction (debris drops get swept up by the suction) ----
  if (CFG.DESTROY_BLOCKS && t.age % 4 === 0) {
    let broken = 0;
    for (let i = 0; i < L.blocks * 3 && broken < L.blocks; i++) {
      const a = Math.random() * Math.PI * 2;
      const dist = Math.sqrt(Math.random()) * rBase * 1.6;
      const bx = Math.floor(t.x + Math.cos(a) * dist);
      const bz = Math.floor(t.z + Math.sin(a) * dist);
      const by = Math.floor(t.y) + Math.floor(Math.random() * 6) - 1;
      try {
        const b = dim.getBlock({ x: bx, y: by, z: bz });
        if (b && canBreak(b.typeId, t.level)) {
          dim.runCommand(`setblock ${bx} ${by} ${bz} air destroy`);
          broken++;
        }
      } catch {}
    }
  }

  // ---- Lightning ----
  if (CFG.LIGHTNING && t.age % L.bolt === Math.floor(L.bolt / 2)) {
    const a = Math.random() * Math.PI * 2, r = rTop * (0.6 + Math.random() * 2);
    strikeLightning(dim, t.x + Math.cos(a) * r, t.z + Math.sin(a) * r, t.y);
  }
  return true;
}

system.runInterval(() => {
  for (let i = tornadoes.length - 1; i >= 0; i--) {
    let alive = true;
    try { alive = stepTornado(tornadoes[i]); }
    catch { if (++tornadoes[i].errors > 200) alive = false; }
    if (!alive) tornadoes.splice(i, 1);
  }
}, 1);

// ===================== TORNADO SUMMONER (item) =====================
world.afterEvents.itemUse.subscribe((ev) => {
  const player = ev.source;
  if (!ev.itemStack || ev.itemStack.typeId !== CFG.ITEM_ID) return;

  // Sneak + use = cycle strength
  if (player.isSneaking) {
    const next = (getLevel(player) + 1) % 6;
    try { player.setDynamicProperty("tornado:ef", next); } catch {}
    player.onScreenDisplay.setActionBar(`§e⚡ Tornado Summoner §7- strength set to §c${EF[next].name}`);
    try { player.playSound("random.orb"); } catch {}
    return;
  }

  const now = system.currentTick;
  if (now - (lastUse.get(player.id) ?? -9999) < CFG.USE_COOLDOWN) return;
  lastUse.set(player.id, now);

  const level = getLevel(player);
  const dim = player.dimension;
  let x, z, y;
  const hit = player.getBlockFromViewDirection({ maxDistance: CFG.MAX_RANGE });
  const blk = hit && (hit.block ?? hit);
  if (blk && typeof blk.x === "number") {
    x = blk.x + 0.5; z = blk.z + 0.5; y = blk.y;
  } else {
    const v = player.getViewDirection(), l = player.location;
    x = l.x + v.x * 25; z = l.z + v.z * 25; y = l.y;
  }

  strikeLightning(dim, x, z, y);
  system.runTimeout(() => {
    if (!spawnTornado(dim, x, z, level)) {
      player.sendMessage("§cToo many tornadoes active! Use /scriptevent tornado:clear");
    }
  }, 20);
});

// ===================== THUNDERBOLT 1000T SIREN (block) =====================
// Place the block, then right-click it to switch the siren on/off.
// It also sounds automatically whenever a tornado is within SIREN_AUTO_RANGE blocks.
const sirens = new Map(); // key -> { dim, x, y, z, manual, next, wasActive }
const skey = (d, x, y, z) => `${d}|${x}|${y}|${z}`;
const toggleCooldown = new Map();

function saveSirens() {
  try {
    world.setDynamicProperty("tornado:sirens", JSON.stringify(
      [...sirens.values()].map((s) => ({ d: s.dim, x: s.x, y: s.y, z: s.z, m: s.manual }))
    ));
  } catch {}
}

function loadSirens() {
  try {
    const raw = world.getDynamicProperty("tornado:sirens");
    if (typeof raw !== "string") return;
    for (const s of JSON.parse(raw)) {
      sirens.set(skey(s.d, s.x, s.y, s.z), { dim: s.d, x: s.x, y: s.y, z: s.z, manual: !!s.m, next: 0, wasActive: false });
    }
  } catch {}
}
system.run(loadSirens);

function registerSiren(block) {
  const k = skey(block.dimension.id, block.x, block.y, block.z);
  if (!sirens.has(k)) {
    sirens.set(k, { dim: block.dimension.id, x: block.x, y: block.y, z: block.z, manual: false, next: 0, wasActive: false });
    saveSirens();
  }
  return sirens.get(k);
}

function silenceSirens(dimId) {
  try { world.getDimension(dimId).runCommand("stopsound @a tornado.siren"); } catch {}
  for (const s of sirens.values()) s.next = 0; // any siren still active restarts right away
}

world.afterEvents.playerPlaceBlock.subscribe((ev) => {
  if (ev.block.typeId !== CFG.SIREN_ID) return;
  registerSiren(ev.block);
  ev.player.onScreenDisplay.setActionBar("§e⚡ Thunderbolt 1000T §7placed. Right-click it to sound the siren.");
});

world.afterEvents.playerBreakBlock.subscribe((ev) => {
  if (ev.brokenBlockPermutation.type.id !== CFG.SIREN_ID) return;
  const b = ev.block;
  if (sirens.delete(skey(b.dimension.id, b.x, b.y, b.z))) {
    saveSirens();
    silenceSirens(b.dimension.id);
  }
});

world.afterEvents.playerInteractWithBlock.subscribe((ev) => {
  const { player, block } = ev;
  if (block.typeId !== CFG.SIREN_ID || player.isSneaking) return;
  const now = system.currentTick;
  if (now - (toggleCooldown.get(player.id) ?? -99) < 10) return; // ignore double-fire
  toggleCooldown.set(player.id, now);

  const s = registerSiren(block);
  s.manual = !s.manual;
  s.next = 0;
  if (!s.manual) silenceSirens(s.dim);
  saveSirens();
  player.onScreenDisplay.setActionBar(s.manual
    ? "§c⚠ Thunderbolt 1000T: SIREN ON"
    : "§aThunderbolt 1000T: siren off");
});

function tornadoNear(s) {
  return tornadoes.some((t) => t.dim === s.dim && Math.hypot(t.x - s.x, t.z - s.z) < CFG.SIREN_AUTO_RANGE);
}

system.runInterval(() => {
  const now = system.currentTick;
  for (const [k, s] of sirens) {
    let dim, b;
    try { dim = world.getDimension(s.dim); b = dim.getBlock({ x: s.x, y: s.y, z: s.z }); } catch {}
    if (!b) continue;                                   // chunk not loaded: skip
    if (b.typeId !== CFG.SIREN_ID) {                    // block was removed some other way
      sirens.delete(k); saveSirens(); continue;
    }
    const active = s.manual || tornadoNear(s);
    if (active) {
      if (now >= s.next) {
        try {
          dim.playSound("tornado.siren", { x: s.x + 0.5, y: s.y + 1, z: s.z + 0.5 }, { volume: CFG.SIREN_VOLUME });
        } catch {}
        s.next = now + CFG.SIREN_LEN_TICKS;
      }
    } else if (s.wasActive) {
      silenceSirens(s.dim);
    }
    s.wasActive = active;
  }
}, 5);

// ===================== COMMANDS =====================
//  /scriptevent tornado:spawn <0-5>   -> tornado 15 blocks in front of you
//  /scriptevent tornado:clear         -> remove all tornadoes
//  /scriptevent tornado:siren off     -> switch every manually-started siren off
system.afterEvents.scriptEventReceive.subscribe((ev) => {
  if (ev.id === "tornado:clear") {
    const n = tornadoes.length;
    tornadoes.length = 0;
    world.sendMessage(`§7Cleared ${n} tornado(es).`);
    return;
  }
  if (ev.id === "tornado:siren") {
    if (ev.message.trim().toLowerCase() === "off") {
      for (const s of sirens.values()) s.manual = false;
      saveSirens();
      world.sendMessage("§7All sirens switched off.");
    }
    return;
  }
  if (ev.id === "tornado:spawn") {
    const lvl = clamp(parseInt(ev.message) || CFG.DEFAULT_EF, 0, 5);
    let dim, x, z;
    if (ev.sourceEntity) {
      const v = ev.sourceEntity.getViewDirection(), l = ev.sourceEntity.location;
      dim = ev.sourceEntity.dimension; x = l.x + v.x * 15; z = l.z + v.z * 15;
    } else if (ev.sourceBlock) {
      dim = ev.sourceBlock.dimension; x = ev.sourceBlock.x + 0.5; z = ev.sourceBlock.z + 0.5;
    } else return;
    if (!spawnTornado(dim, x, z, lvl)) world.sendMessage("§cToo many tornadoes active!");
  }
});
